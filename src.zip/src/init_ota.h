#ifndef INIT_OTA
#define INIT_OTA
#include <WiFiUdp.h>
#include <ArduinoOTA.h>

void init_ota();

#endif